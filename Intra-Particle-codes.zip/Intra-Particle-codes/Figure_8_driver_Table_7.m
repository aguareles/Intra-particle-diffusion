close all; clear all; clc
% This code, written by L. C. Auton produces Figure 8 and Table 7 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% The fitting functions called within were written by  A. Valverde.
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Global parameters (model) 
a= 1; %Remains fixed for all cases.

%Colour map for lines
cmaps1 = copper(8);
cmaps1(8,:) = [246/255 198/255 130/255];
cmaps2 = parula(5); 
cmaps2(4,:) = [206/255 228/255 126/255]; 

%Fontsize and line widths
LWF = .5; %Line width for data points shapes 
FS=10;  % Font size for text
LW=1.25;   % Line width
ini=1;  % Starting index for plotting

% Experimental conditions 

%Control parameters
MCO2=0.044; %[kg/mol] % Mass of C0_2 
T=25+273.15; %[K] % Temperature
P=101325; %[Pa] Atmospheric pressure
Rg=8.314; %[J/(Kmol)] %The molar (or universal) gas constant
rhoCO2=P*MCO2/(Rg*T); % Density of C0_2

cippm=405; %[ppm] inlet concentration parts per million 
ci=(cippm/1000)*rhoCO2/(1000*MCO2);  % inlet concentration in [mol/m3]

mm_batch=0.0759/MCO2; %mm_batch is maximum determined using batch experiments for 0.25-0.5 mm [mol/kg]
memm_batch=0.0737/(MCO2*mm_batch); % Remains constant for all particle sizes: 1/mu = me/mm_batch
mu=1/memm_batch; % as defined in \S2.4

%Preallocate size of vectors for speed
N = 1000; 
[Data1,~,~,Data4] = Figure_8_9_data; 
t=zeros(N,2,3);
c = t; 

Rs = [0.25e-3/2, 1.7e-3/2];   %Vector of radii of porous grains [m]
bs = [1,2,3];

%Initialise vectors
Tau = zeros(length(bs), length(Rs)); 
beta = Tau; 
SSE = Tau; 
R2 = Tau; 

for iR = 1:2 
    R = Rs(iR); 
    if iR == 1  
        Data = Data1;
    elseif iR ==2 
        Data = Data4;
    end 
        texp=Data(:,1)';   %[h] 
        cexp=Data(:,2)'/cippm;   %  normalised outlet concentration; experimentally determined
        texp_secs = texp*3600; %[s]
        vec = find (cexp<0.5);
        indexL = vec(end);
        vec = find (cexp>=0.5);
        indexU = vec(1);

    for ib = 1:length(bs)
        b = bs(ib);
        t12=interp1([cexp(indexL),cexp(indexU)],[texp_secs(indexL),texp_secs(indexU)],0.5); %[s]
        tt12exp = texp_secs-t12;
        if iR ==1 
            t12 = 10.73*3600; % manually adjust for halftime as data a little wavy around c=0.5 
            tt12exp = texp_secs-t12;
            if (mu <1.02985074626865) || (mu>1.02985074626866)
                warning('!!!You must manually change the mu value entered in fig_8_9ab_opt!!!')
            end
            fitresult = fig_8_9ab_opt(cexp, tt12exp, b);
        elseif iR ==2 
            if (mu <1.02985074626865) || (mu>1.02985074626866)
                warning('!!!You must manually change the mu value entered in fig_8_9d_opt!!!')
            end
            fitresult = fig_8_9d_opt(cexp, tt12exp, b);
        end 
        % Please note, when beta is large (~1e5) its precise value depends
        % on the version of MATLAB that is used. The order of magnitude
        % remains constant. 

        Tau(ib,iR) = fitresult.tau;
        beta(ib,iR) = fitresult.beta;
        tss = linspace(0, max(texp_secs), N  ); 
        [t_ana_minus_t12, c(:,iR,ib)] = Analytical_calculator(tss-t12, a, b, mu, Tau(ib,iR), beta(ib,iR));
        t(:,iR,ib) = t_ana_minus_t12 +t12;
        [SSE(ib,iR),R2(ib,iR)] = goffun(cexp, tt12exp, c(:,iR,ib), t_ana_minus_t12);
       
    end
    %Table 3
    disp('Table 7')
    display(['R =' num2str(Rs(iR))])
    display(['b =' num2str(bs)])
    display(['Tau =' num2str(Tau(:,iR)')])
    display(['beta=' num2str(beta(:,iR)')])
    display(['SSE =' num2str(SSE(:,iR)')])
    display(['R-squared =' num2str(R2(:,iR)')])
end 



%PLOTS
figure(8)
subplot(121)
scatter(Data1(:,1),Data1(:,2)/cippm,'marker','square', 'MarkerEdgeColor',cmaps1(3,:),'LineWidth', LWF);
hold on 
plot(t(:,1,1)/3600,c(:,1,1),'Color',cmaps2(1,:),'LineWidth',LW)
plot(t(:,1,2)/3600,c(:,1,2),'Color',cmaps2(3,:),'LineWidth',LW)
plot(t(:,1,3)/3600,c(:,1,3),'Color',cmaps2(4,:),'LineWidth',LW)
grid on
xlab=xlabel('t (h)','Interpreter','latex','FontSize',FS);
ylab=ylabel('$\bar{c}/c_{in}$','Interpreter','latex','FontSize',FS);
xlab.FontSize=FS;
ylab.FontSize=FS;
ylim([0 1])
xlim([min(Data1(:,1)) max(Data1(:,1))])
leg=legend('$R = 1.25\times10^{-4}\ \mathrm{m}$','$a=1$, $b=1$','$a=1$, $b=2$','$a=1$, $b=3$');
set(leg, 'Interpreter', 'Latex','location','southeast') 
set(gca,'FontSize',FS,'LineWidth',1)
set(gca,'TickLabelInterpreter','latex')


subplot(122)
scatter(Data4(:,1),Data4(:,2)/cippm,'marker','square', 'MarkerEdgeColor',cmaps1(8,:),'LineWidth', LWF);
hold on 
plot(t(:,2,1)/3600,c(:,2,1),'Color',cmaps2(1,:),'LineWidth',LW)
plot(t(:,2,2)/3600,c(:,2,2),'Color',cmaps2(3,:),'LineWidth',LW)
plot(t(:,2,3)/3600,c(:,2,3),'Color',cmaps2(4,:),'LineWidth',LW)
grid on
xlab=xlabel('t (h)','Interpreter','latex','FontSize',FS);
ylab=ylabel('$\bar{c}/c_{in}$','Interpreter','latex','FontSize',FS);
xlab.FontSize=FS;
ylab.FontSize=FS;
ylim([0 1])
xlim([min(Data4(:,1)) max(Data4(:,1))])
leg=legend('$R=8.5 \times 10^{-4}\ \mathrm{m}$','$a=1$, $b=1$','$a=1$, $b=2$','$a=1$, $b=3$');
set(leg, 'Interpreter', 'Latex','location','southeast') 
set(gca,'FontSize',FS,'LineWidth',1)
set(gca,'TickLabelInterpreter','latex')

%Format and print figure
% Two figures in two columns
figw = 17.2; % [cm]
subfigw = 0.38; % Fraction of figw
subfigh = 0.75; % Fraction of figh
padleft = 1.5/figw; % Fraction of figw
padbottom = 3/figw; % Fraction of figw
padbetween = 1.3/figw; % Fraction of figw
figh = figw/(2.7); %Figure height realtive to figure width

for i=1:2
    subplot(1,2,i)
    box on
    set(gca,'FontSize',10,'FontName','Times New Roman')
    if i == 1 
        xlab=xlabel('t (h)','Interpreter','latex','FontSize',FS);
        ylab=ylabel('$\bar{c}/c_{in}$','Interpreter','latex','FontSize',FS);
        xlab.FontSize=FS;
        ylab.FontSize=FS;
    elseif i==2 
        xlab=xlabel('t (h)','Interpreter','latex','FontSize',FS);
        ylab=ylabel('$\bar{c}/c_{in}$','Interpreter','latex','FontSize',FS);
        xlab.FontSize=FS;
        ylab.FontSize=FS;
    end 
end

subplot(1,2,1)
set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
box on 
subplot(1,2,2)
set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom,subfigw,subfigh])
box on 
set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf','./Figures/Figure_8.pdf');


clear all; close all; clc;
% This code, written by L. C. Auton produces Figure 6 and Table 4 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% The fitting functions called within were written by  A. Valverde.
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Global parameters (model) 
a= 1; %Remains fixed for all cases.
b=2; %Remains fixed for all cases.

%Experimental conditions 

%Control parameters
MHg=0.20059; %[kg/mol] % Mass of Hg 
ci=50/(1000*MHg); %[mol/m3] inlet concentration

%Physcial parameters for smaller pellets
Q=1.4e-6; %[m^3/s] Volumetric flow rate
Db=50e-3; %[m] %Diameter of filter 
Lb=0.05; %[m] % dimensional filter length 
Sb=pi*(Db^2)/4; %[m^2] Cross-sectional area of filter 
Vb=pi*(Db^2)*Lb/4; %[m^3] Volume of filter 
rhob=784.34; %[kg/m^3]
phi=0.601; % Inter-particle porosity 
phip=0.76; %Intra-particle porosity
us=Q/Sb; %[m/s] % instantenous or volumetric flux
u=Q/(phi*Sb); %[m/s] % flow velocity 
mad=rhob*Vb; %Adsorbent mass [kg]
D=3.0551e-9; % Approximated via a chart in Levenspiel (1999)
      
me_iso = 0.00945945945945946/MHg; %[mol/kg] % Extracted from Yousif et al. (2013), Figure 2.

[ceHg, meHg, MHg] = Figure_5_data;

[fitresult, gof] = Figure_5_opt(ceHg, meHg, a/b);
mm_isoKtothe1overb = fitresult.f; %mmax*K^{1/b}
Ktothe1overb = fitresult.g; % K^{1/b} 
mm_iso = mm_isoKtothe1overb/Ktothe1overb;
memm_batch=me_iso./mm_iso;
mu=1/memm_batch+1; % as defined in \S2.4 

%Preallocate size of vectors for speed
N = 1000; 
kplus=zeros(1,4);
kp=zeros(1,4);  
L=zeros(1,4);
LLb=zeros(1,4);
Peinv=zeros(1,4);
Da=zeros(1,4);
K=zeros(1,4);
alpha=zeros(1,4);
kminus = zeros(1,4);
t12 = zeros(1,4);
SSE = zeros(1,4);
R2 =zeros(1,4);
Taus = zeros(1,4);% Characteristic timescale 
betas= zeros(1,4);
cs = zeros(4,N);
ts = zeros(4,N);
t_ana = zeros(4,N);
t_ana_minus_t12= zeros(4,N);

[Data02, Data04, Data06, Data08] = Figure_6_data;


Rs = [0.206e-3/2, 0.38e-3/2, 0.615e-3/2, 0.778e-3/2];   %Vector of radii of porous grains [m]

for iR = 1:length(Rs)  
    
    R = Rs(iR);
    
    if iR == 1  
        Data = Data02;
    elseif iR ==2 
        Data = Data04;
    elseif iR == 3  
        Data = Data06;
    elseif iR == 4  
        Data = Data08;
    end 
    
    texp=Data(:,1)'; %[s]
    cciexp=Data(:,2)'; % experimentally determined outlet concentration [ppm] (smaller grains)
    tss = linspace(0,texp(end), N);

    me=trapz(texp,1-cciexp)*u*Sb*phi*ci/mad; %[mol/kg]
    
    % Calculate the values and nearset indices to C=1/2. 
    vec = find (cciexp<0.5);
    indexL = vec(end);
    vec = find (cciexp>=0.5);
    indexU = vec(1);
    
    t12(iR) =interp1([cciexp(indexL),cciexp(indexU)],[texp(indexL),texp(indexU)],0.5); %[s]

    [fitresult] = Figure_6_opt(cciexp, texp-t12(iR), b, mu);

    Taus(iR) = fitresult.Tau; 
    betas(iR) = fitresult.beta; 

    t_inpt = tss-t12(iR);
    [t_ana_minus_t12(iR,:), cs(iR,:)] = Analytical_calculator(t_inpt, a, b, mu, Taus(iR), betas(iR));
    ts(iR,:) = t_ana_minus_t12(iR,:) +t12(iR);


    [SSE(iR),R2(iR)] = goffun(cciexp,texp-t12(iR),cs(iR,:),t_ana_minus_t12(iR,:));
    
    %Store and calculate parameters (Table 4)
    me(iR) = me; 
    kplus(iR) = me(iR)^(1-b)/Taus(iR)/ci^a; 
    K(iR)=1/((ci^a)*((1/memm_batch)-1)^b); %Constant for all R
    L(iR)=u*Taus(iR)*phi*ci/(rhob*me(iR)); % reaction length scale
    LLb(iR)=Lb/L(iR); % dimensionless filter length
    Peinv(iR)=D/(u*L(iR)); % Inverse Peclet number
    Da(iR)=L(iR)/(u*Taus(iR)); % Damkohler number
    alpha(iR)=phip*(1-phi)*Da(iR)/phi; % alpha as defined in \S2.4
    kp(iR) = betas(iR)*R*phi/3/Taus(iR)/Da(iR)/(1-phi); %Spheres
    kminus(iR)=kplus(iR)/K(iR); %k_-

     
end


%Table 4 
disp('Table 4')
display(['b =' num2str((b))])
display(['R =' num2str((Rs))])
display(['Tau =' num2str((Taus))])
display(['beta =' num2str((betas))])
display(['k_+=' num2str((kplus))])
display(['k_-=' num2str((kminus))])
display(['k_p=' num2str((kp))])
display(['L=' num2str((L))])
display(['Inv. Pe=' num2str((Peinv))])
display(['Da=' num2str((Da))])
display(['alpha=' num2str((alpha))])
display(['half-time=' num2str((t12/3600))])
display(['SSE=' num2str((SSE))])
display(['R^2=' num2str((R2))])


%Colour map for lines and plotting params
nc= 100; 
cmap=copper(nc); 
LW = 1 ; 
LW2 = 1;
FS=10;

cmaps = flipud([cmap(round(3.2*(nc+20)/4),:); cmap(round(2.3*(nc+20)/4),:);cmap(round(1.7*(nc+20)/4),:);cmap(round((nc+20)/4),:)]);

%keyboard 
for iR = 1:4 
    if iR == 1  
        Data = Data02;
    elseif iR ==2 
        Data = Data04;
    elseif iR == 3  
        Data = Data06;
    elseif iR == 4  
        Data = Data08;
    end 
    
    texp=Data(:,1)'; %[s]
    cciexp=Data(:,2)'; 
    
    figure(6)
    hold on 
    scatter(texp/3600,cciexp,'marker','square','MarkerEdgeColor',cmaps(iR,:),'LineWidth', LW);
end 

for iRb = 1:4 

    if iRb == 1  
        Data = Data08;
    elseif iRb ==2 
        Data = Data06;
    elseif iRb == 3  
        Data = Data04;
    elseif iRb == 4  
        Data = Data02;
    end 
    
    texp=Data(:,1)'; %[s]
    cciexp=Data(:,2)';
    
    figure(6)
    hold on
    plot([ts(5-iRb,:),2.5*3600]/3600,[cs(5-iRb,:),0.9999999],'-','LineWidth',LW2,'Color',cmaps(5-iRb,:));

end 
grid on
xlab=xlabel('t (h)','Interpreter','latex','FontSize',FS);
ylab=ylabel('$\bar{c}/c_{in}$','Interpreter','latex','FontSize',FS);
xlab.FontSize=FS;
ylab.FontSize=FS;
ylim([0 1.01])
xlim([0 2.2])
box on 
set(gca,'FontSize',FS,'FontName','Times New Roman','LineWidth', 1)

leg=legend( '','','','','$R=3.89\times10^{-4}$ m', '$R=3.075\times10^{-4}$ m', '$R=1.9\times10^{-4}$ m', '$R=1.03\times10^{-4}$ m');
set(leg, 'Interpreter', 'Latex','Position',[0.245 0.62 0.02 0.25], 'FontSize',8,'FontName','Times New Roman','LineWidth', 1)
% first number increasing it moves it to the right 
% second increasing it moves it up 
% third number controls insert width 
% fourth controls insert height    
set(gca,'TickLabelInterpreter','latex')
figw = 17.2; % cm
figh = .3333*figw; 
box on
set(gca,'FontSize',10,'FontName','Times New Roman','linewidth',1)
set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw-2.4 figh-.1])
set(gcf,'PaperPosition',[-1.1 0 figw+.2 figh])
print(gcf,'-dpdf','./Figures/Figure_6.pdf');
    

clear all; close all; clc; 
% This code, written by L. C. Auton produces Figure 9 and Table 8 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% The fitting functions called within were written by  A. Valverde.
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Global parameters (model) 
a= 1; %Remains fixed for all cases.
b=2; %Remains fixed for all cases.

%Global parameters (Plotting)

%Colour map for lines
cmap2= copper(8); 
cmap = parula(5); 
cmap2(8,:) = [ 246/255 198/255 130/255];
cmap2(6,:) = [ 215/255 130/255 73/255];

%Fontsize and line widths
LWF = .5; %Line width for data points shapes 
FS=10;  % Font size for text
LW=1.25;   % Line width
ini=1;  % Starting index for plotting

%Experimental conditions 

%Control parameters
MCO2=0.044; %[kg/mol] % Mass of C0_2 
T=25+273.15; %[K] % Temperature
P=101325; %[Pa] Atmospheric pressure
Rg=8.314; %[J/(Kmol)] %The molar (or universal) gas constant
rhoCO2=P*MCO2/(Rg*T); % Density of C0_2

%Physcial parameters for smaller pellets
Q=335*(1e-6)/60; %[m^3/s] Volumetric flow rate
Vpore=0.4e-3; %[m^3/kg]
mad=2.72e-3; %Adsorbent mass [kg]
Db=8e-3; %[m] %Diameter of filter 
Lb=0.1; %[m] % dimensional filter length 
Sb=pi*(Db^2)/4; %[m^2] Cross-sectional area of filter 
Vb=pi*(Db^2)*Lb/4; %[m^3] Volume of filter 
rhob=mad/Vb; %[kg/m^3]
phi=0.48; % Inter-particle porosity 
phip=mad*Vpore/(Vb*(1-phi)); %Intra-particle porosity
us=Q/Sb; %[m/s] % instantenous or volumetric flux
u=Q/(phi*Sb); %[m/s] % flow velocity 

cippm=405; %[ppm] inlet concentration parts per million 
ci=(cippm/1000)*rhoCO2/(1000*MCO2);  % inlet concentration in [mol/m3]

mm_batch=0.0759/MCO2; %mm_batch is maximum determined using batch experiments for 0.25-0.5 mm [mol/kg]
memm_batch=0.0737/(MCO2*mm_batch); % Remains constant for all particle sizes: me/mm_batch
mu=1/memm_batch; % as defined in \S2.4

N =1000; 
Rs = [0.25e-3/2,((0.25+0.5)/2)*1e-3/2, ((0.5+1.7)/2)*1e-3/2, 1.7e-3/2];   %Vector of radii of porous grains [m]

%Preallocate size of vectors for speed
Tau = zeros(length(Rs),1); 
beta = Tau; 
SSE = Tau; 
R2 = Tau; 
kplus  = Tau;
kminus = Tau;
kp = Tau;
L = Tau;
K  = Tau;
LLb = Tau;
Peinv  = Tau;
Da = Tau;
alpha = Tau;

[Data1,Data2,Data3,Data4] = Figure_8_9_data; 

t=zeros(N,2,3);
c = t; 
Ds = [6e-5 9e-5 2.6e-4 4.1e-4]; % Approximated via a chart in Levenspiel (1999)
meexps = [0.071 0.0737 0.0748 0.0818]/MCO2; %[mol/kg] Experimental equilibrium amount adsorbed


for iR = 1:length(Rs) 
    R = Rs(iR); 
    if iR == 1  
        Data = Data1;
    elseif iR ==2 
        Data = Data2;
    elseif iR ==3 
         Data = Data3; 
    elseif iR ==4 
        Data = Data4;
    end 
    texp=Data(:,1)';   %[h] 
    cexp=Data(:,2)'/cippm;   %  normalised outlet concentration; experimentally determined
    texp_secs = texp*3600; %[s]
    vec = find (cexp<0.5);
    indexL = vec(end);
    vec = find (cexp>=0.5);
    indexU = vec(1);
    t12=interp1([cexp(indexL),cexp(indexU)],[texp_secs(indexL),texp_secs(indexU)],0.5); %[s]
    tt12exp = texp_secs-t12;
    if iR ==1  
        t12 = 10.73*3600; % manually adjust fit for halftime as data a little wavy around c=0.5 
        tt12exp = texp_secs-t12;
        if (mu <1.02985074626865) || (mu>1.02985074626866)
            warning('!!!You must manually change the mu value entered in fig_8_9ab_opt!!!')
        end
        fitresult = fig_8_9ab_opt(cexp, tt12exp, b); 
    elseif iR ==2 
        t12 = t12-1000; % manually adjust for halftime as data a little wavy around c=0.5 
        tt12exp = texp_secs-t12;
        if (mu <1.02985074626865) || (mu>1.02985074626866)
            warning('!!!You must manually change the mu value entered in fig_8_9ab_opt!!!')
        end
        fitresult = fig_8_9ab_opt(cexp, tt12exp, b); 
    elseif iR == 3 
        if (mu <1.02985074626865) || (mu>1.02985074626866)
            warning('!!!You must manually change the mu value entered in fig_8_9c_opt!!!')
        end        
        fitresult = fig_8_9c_opt(cexp, tt12exp, b); 
    elseif iR ==4  
        if (mu <1.02985074626865) || (mu>1.02985074626866)
            warning('!!!You must manually change the mu value entered in fig_8_9d_opt!!!')
        end
        fitresult = fig_8_9d_opt(cexp, tt12exp, b); 
    end 
    % Please note, when beta is large (~1e5) its precise value depends
    % on the version of MATLAB that is used. The order of magnitude
    % remains constant. 

    Tau(iR) = fitresult.tau;
    beta(iR) = fitresult.beta;
    tss = linspace(0, max(texp_secs), N  ); 
    [t_ana_minus_t12, c(:,iR)] = Analytical_calculator(tss-t12, a, b, mu, Tau(iR), beta(iR));
    t(:,iR) = t_ana_minus_t12 +t12;
    [SSE(iR),R2(iR)] = goffun(cexp, tt12exp, c(:,iR), t_ana_minus_t12);

    D = Ds(iR); 
    kplus(iR) = meexps(iR)^(1-b)/Tau(iR)/ci^a; 
    K(iR)=1/((ci^a)*((1/memm_batch)-1)^b); %Constant for all R
    L(iR)=u*Tau(iR)*phi*ci/(rhob*meexps(iR)); % reaction length scale
    LLb(iR)=Lb/L(iR); % dimensionless filter length
    Peinv(iR)=D/(u*L(iR)); % Inverse Peclet number
    Da(iR)=L(iR)/(u*Tau(iR)); % Damkohler number
    alpha(iR)=phip*(1-phi)*Da(iR)/phi; % alpha as defined in \S2.4
    kp(iR) = beta(iR)*R*phi/3/Tau(iR)/Da(iR)/(1-phi); %Spheres
    kminus(iR)=kplus(iR)/K(iR); %k_-
    t12_dim(iR)=t12/3600;
end

%Table 8 
disp('Table 8')
display(['Tau =' num2str(Tau')])
display(['beta =' num2str(beta')])
display(['k_+=' num2str(kplus')])
display(['k_-=' num2str(kminus')])
display(['k_p=' num2str(kp')])
display(['L=' num2str(L')])
display(['Inv. Pe=' num2str(Peinv')])
display(['Da=' num2str(Da')])
display(['alpha=' num2str(alpha')])
display(['half-time=' num2str(t12_dim)])
display(['SSE =' num2str(SSE')])
display(['R-squared =' num2str(R2')])

% Figure 9
figure(9)

subplot(221)
scatter(Data1(:,1),Data1(:,2)/cippm,'marker','square', 'MarkerEdgeColor',cmap2(3,:),'LineWidth', LWF);
hold on
plot(t(:,1)/3600,c(:,1),'Color',cmap(3,:),'LineWidth',LW)
grid on
ylim([0 1])
xlim([min(Data1(:,1)) max(Data1(:,1))])
leg=legend('$R=1.25\times 10^{-4}\ \mathrm{m}$','$a=1, \ b=2$');
set(leg, 'Interpreter', 'Latex','location','southeast') 

subplot(222)
scatter(Data2(:,1),Data2(:,2)/cippm,'marker','square', 'MarkerEdgeColor',cmap2(4,:),'LineWidth', LWF);
hold on
plot(t(:,2)/3600,c(:,2),'Color',cmap(3,:),'LineWidth',LW)
grid on
xlim([min(Data2(:,1)) max(Data2(:,1))])
leg=legend('$R=1.875\times 10^{-4}\ \mathrm{m}$','$a=1, \ b=2$');
set(leg, 'Interpreter', 'Latex','location','southeast') 

subplot(223)
scatter(Data3(:,1),Data3(:,2)/cippm,'marker','square', 'MarkerEdgeColor',cmap2(6,:),'LineWidth', LWF);
hold on
plot(t(:,3)/3600,c(:,3),'Color',cmap(3,:),'LineWidth',LW)
grid on
ylim([0 1])
xlim([min(Data3(:,1)) max(Data3(:,1))])
leg=legend('$R=5.5\times 10^{-4}\ \mathrm{m}$','$a=1, \ b=2$');
set(leg, 'Interpreter', 'Latex','location','southeast') 

subplot(224)
hold on
scatter(Data4(:,1),Data4(:,2)/cippm,'marker','square', 'MarkerEdgeColor',cmap2(8,:),'LineWidth', LWF);
plot(t(:,4)/3600,c(:,4),'Color',cmap(3,:),'LineWidth',LW)
grid on
ylim([0 1])
xlim([min(Data4(:,1)) max(Data4(:,1))])
leg=legend('$R=8.5\times 10^{-4}\ \mathrm{m}$','$a=1, \ b=2$');
set(leg, 'Interpreter', 'Latex','location','southeast') 

% Two figures in two columns
figw = 17.2; % cm
subfigw = 0.42; % Fraction of figw
subfigh = 0.39; % Fraction of figh
padleft = 1.35/figw; % Fraction of figw
padbottom = 1.8/figw; % Fraction of figw
padbetween = 1.2/figw; % Fraction of figw
figh = .55*figw; 

for i=1:2

    subplot(2,2,1+(i-1))
    box on
    set(gca,'FontSize',10,'FontName','Times New Roman')
    if i==1
        ylabel('$\bar{c}/c_{in}$','Interpreter','latex')
    end

    subplot(2,2,3+(i-1))
    box on
    set(gca,'FontSize',10,'FontName','Times New Roman')
    xlabel('$t$ (h)','Interpreter','latex')
    if i==1
        ylabel('$\bar{c}/c_{in}$','Interpreter','latex')
    end  
end

subplot(2,2,1)
set(gca,'Position',[padleft,padbottom+(subfigh+1.2*padbetween),subfigw,subfigh])
subplot(2,2,2)
set(gca,'Position',[padleft+(subfigw+1*padbetween),padbottom+(subfigh+1.2*padbetween),subfigw,subfigh])

subplot(2,2,3)
set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
subplot(2,2,4)
set(gca,'Position',[padleft+(subfigw+1*padbetween),padbottom,subfigw,subfigh])

set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf','./Figures/Figure_9.pdf');

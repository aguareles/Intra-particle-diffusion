function [ceHg, meHg, MHg] = Figure_5_data
% This code, written by L. C. Auton, contains the data used in Figure 5 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% Data extracted from Yousif et al. [20], by A. Valverde
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MHg=0.20059; %[kg/mol]mass of mecury 

%input experimental data
Hg=[0, 0
0.11627906976744207, 1.538461538461533
0.9302325581395356, 2.435897435897431
3.3720930232558137, 4.615384615384613
10.232558139534884, 7.820512820512818
18.02325581395349, 8.333333333333336
26.27906976744186, 9.358974358974358
31.860465116279073, 9.487179487179482
36.627906976744185, 10.256410256410255
43.48837209302326, 10];

%Convert data to given units
ceHg=Hg(:,1)/(1000*MHg);
meHg=Hg(:,2)/(1000*MHg);

end 
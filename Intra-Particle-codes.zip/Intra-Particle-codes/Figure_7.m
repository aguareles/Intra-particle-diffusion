close all; clear all; clc
% This code, written by L. C. Auton produces Figure 7 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% The fitting functions called within were written by  A. Valverde.
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Input data 
data=[0.002791291	0
0.00295615	2.104134154
0.003046421	3.540959324
0.003142379	4.177459469
0.003243861	4.317488114
0.003352883	4.248495242];

%Define material parameter
MCO2=0.044; %[kg/mol] mass of C02.

%Extract Experimental data 
Tinv=data(:,1); % 1/ temperature 
meln=data(:,2); % log(me)
me=exp(meln)/(1000*MCO2); %me
meinv=1./me; % 1/me

%Call optimisation function
[fitresult, gof] = Figure_7_opt(meinv, Tinv);

%Determined by optimisation 
F=fitresult.F; %(Rg/dH)*ln(A*ci.^a*mm.^b)
G=fitresult.G;  % = b*Rg/dH
mm=1/fitresult.invmm;  %[mg/g]

%Build mesh
xmesh=min(meinv):0.0001:max(meinv);

%Parameters for plotting.
forest = [14/255, 92/255, 19/255]; 
lilac = [144/255, 102/255, 232/255]; 
FS=10;  % Font size for text
LW=1.25;   % Line width

%Plot Figure 
figure(7)

plot(xmesh,F+G*log(xmesh-1/mm),'-','Color',forest, 'LineWidth',LW)
hold on
scatter(meinv,Tinv,'marker','^', 'MarkerEdgeColor',lilac,'LineWidth', LW);
hold off
grid off
xlab=xlabel('$1/\overline{m}_e$ (kg/mol)','Interpreter','latex','FontSize',FS);
ylab=ylabel('$1/T$ (K$^{-1}$)','Interpreter','latex','FontSize',FS);
xlab.FontSize=FS;
ylab.FontSize=FS;
set(gca,'FontSize',FS,'LineWidth',1)
set(gca,'TickLabelInterpreter','latex')

%Prettify Figure
figw = 17.2; % cm figure width
figh = .33333*figw; %figure height (fraction of width) 
box on
grid on
set(gca,'FontSize',10,'FontName','Times New Roman','linewidth',1)
set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw-2.3 figh+.05])
set(gcf,'PaperPosition',[-1.1 0 figw+.2 figh])
print(gcf,'-dpdf','./Figures/Figure_7.pdf');
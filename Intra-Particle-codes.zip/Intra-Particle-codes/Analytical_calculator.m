function [t_ana_minus_t12, c_ana] = Analytical_calculator(t_inpt, a, b, mu, Tau, beta)
    % This function, written by L. C. Auton, A. Valverde and M. Calvo-
    % Schwarzwalder, provides the analytical travelling wave solutions for
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    L = 1e-11;
    U = 1-L;
    cfit = zeros(size(t_inpt));
    if a==1 
        for it = 1:length(t_inpt)
            t_star=t_inpt(it);
        
            if b ==1 
                tfit = @(c) (Tau/beta)*(log(2) + ((beta+mu)*log(c)+(1-beta-mu)*log(1-c)) )-t_star;
              
            elseif b ==2 
            
                tfit = @(c) (Tau/beta)*( ((1+beta/(mu^2))*log(c)-((beta+(mu-1)^2)/(-1+mu^2))...
                *log(1-c)+((beta+(mu^2)*(mu-1)^2)/((-1+mu^2)*mu^2))...
                *log((mu^2)-c)) - ((1+beta/(mu^2))*log(0.5)-((beta+(mu-1)^2)/(-1+mu^2))...
                *log(0.5)+((beta+(mu^2)*(mu-1)^2)/((-1+mu^2)*mu^2))*log((mu^2)-0.5)) )-t_star; 
                
                
            elseif b==3 
                
                if mu>1 && mu<4
                    tfit = @(c) (Tau/beta)*( ((1+beta/(mu^3))*log(c)-((beta+(mu-1)^3)/(((mu-1)^2)*(2*mu+1)))*log(1-c)...
                    +((beta*(-1+(mu^2)*(3-mu))+(mu^3)*(mu-1)^3)/(2*(mu^3)*((mu-1)^2)*(2*mu+1)))*...
                    log( ((c-(mu^2)*(3-mu)/2).^2)+ (mu^3)*(1-mu*((3-mu)^2)/4) ) - ...
                    ((beta*(3-mu*(4-mu)*(mu-1))+3*(mu^3)*(mu-1)^3)/((2*mu*(mu-1)*(2*mu+1))...
                    *sqrt((mu^3)*(1-mu*((3-mu)^2)/4))))*atan((c-(mu^2)*(3-mu)/2)/...
                    sqrt((mu^3)*(1-mu*((3-mu)^2)/4))) ) - ((1+beta/(mu^3))*log(0.5)-...
                    ((beta+(mu-1)^3)/(((mu-1)^2)*(2*mu+1)))*log(0.5)+((beta*(-1+(mu^2)*(3-mu))...
                    +(mu^3)*(mu-1)^3)/(2*(mu^3)*((mu-1)^2)*(2*mu+1)))*log( ((0.5-(mu^2)*(3-mu)/2).^2)...
                    + (mu^3)*(1-mu*((3-mu)^2)/4) ) - ((beta*(3-mu*(4-mu)*(mu-1))+3*(mu^3)*(mu-1)^3)...
                    /((2*mu*(mu-1)*(2*mu+1))*sqrt((mu^3)*(1-mu*((3-mu)^2)/4))))*atan((0.5-(mu^2)*(3-mu)/2)...
                    /sqrt((mu^3)*(1-mu*((3-mu)^2)/4))) ))-t_star; 
                elseif mu ==4
                tfit = @(c) (Tau/beta)*( (beta+64)*log(c)/64 - (beta+27)*log(1-c)/81 ...
                    + (1728-17*beta)*log(c+8)/5184 + (beta+1728)./(72*(c+8)) - ...
                    ((beta+64)*log(1/2)/64 - (beta+27)*log(1-1/2)/81 ...
                    + (1728-17*beta)*log(1/2+8)/5184 + (beta+1728)./(72*(1/2+8))))-t_star; 
                elseif mu>4
                    nplus = -mu^2*(mu-3)/2+sqrt(mu^2*(mu-3)/4-mu^3);
                    nminus = -mu^2*(mu-3)/2-sqrt(mu^2*(mu-3)/4-mu^3);
                    a1 = beta/mu^3+1;
                    a2 = (beta+(mu-1)^3)/(mu-1)^2/(2*mu+1);
                    a3 = (beta+(mu-nplus)^3)/nplus/(1-nplus)/(nplus-nminus);
                    a4 = (beta+(mu-nminus)^3)/nminus/(1-nminus)/(nminus-nplus);
                    
                   tfit = @(c) (Tau/beta)*( ...
                          a1*log(c)-a2*log(1-c)+a3*log(c-nplus)+a4*log(c-nminus) - ...
                          (a1*log(1/2)-a2*log(1/2)+a3*log(1/2-nplus)+a4*log(1/2-nminus)))-t_star;
                end 
            end 
            try 
                cfit(it) = fzero(@(c) tfit(c), [L, U]);
            catch
                if it>1 && 1-cfit(it-1)< 1e-10
                    cfit(it) =1;
                elseif it ==1 
                    cfit(it) = 0;
                elseif cfit(1:it-1) == 0
                    cfit(it) = 0;
                end 
            end 
        end 
    else
    disp('Warning failure to find root to implicit expression')
    end 
    
    c_ana = cfit;
    t_ana_minus_t12 = t_inpt; 

end 
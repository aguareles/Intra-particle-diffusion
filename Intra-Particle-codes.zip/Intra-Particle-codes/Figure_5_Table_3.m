clear all; close all; clc;
% This code, written by L. C. Auton produces Figure 5 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% The fitting functions called within were written by  A. Valverde
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[ceHg, meHg, MHg] = Figure_5_data;

%We prescribe the following a,b combinations
as = [1 2 1];
bs = [1 3 2];
ns = as./bs; % a/b 

mmaxKtothe1overb = zeros(1,length(ns)+1);
Ktothe1overb = zeros(1,length(ns)+1);
SSE = zeros(1,length(ns)+1);
R2 = zeros(1,length(ns)+1);

for in = 1:length(ns)
    n =ns(in);
    [fitresult, gof] = Figure_5_opt(ceHg, meHg, n);
    mmaxKtothe1overb(1,in) = fitresult.f;%mmax*K^{1/b}
    Ktothe1overb(1,in) = fitresult.g; % K^{1/b} 
    %Goodness of fit parameters
    SSE(1,in) = gof.sse;
    R2(1,in)= gof.rsquare;
end 

%Now we fit for n as well: 
[fitresult, gof] = Figure_5_opt_ab(ceHg, meHg);
mmaxKtothe1overb(1, length(ns)+1) = fitresult.f;
Ktothe1overb(1,length(ns)+1) = fitresult.g;
% Now we determine a/b via use of a/b as a fitting parameter.
n =[ns fitresult.n]; % a/b 
%Goodness of fit parameters
SSE(1,length(ns)+1) = gof.sse;
R2(1,length(ns)+1)= gof.rsquare;


mm = mmaxKtothe1overb./Ktothe1overb; %m_max
K1b = Ktothe1overb;  %  K1b= K^{1/b} 

%Table 3
display('Table 3')
display(['a/b =' num2str(n)])
display(['m_max =' num2str(mm)])
display(['K^1/b =' num2str(K1b)])
display(['SSE=' num2str(SSE)])
display(['R^2=' num2str(R2)])


%Plotting parameters 
cmap = parula(5); 
nc = 100;
cmap2 = parula(nc);
FS=10;  % Font size for text
LW=1.25;   % Line width

ce=0:0.0001:0.5;

figure(5)
subplot(121)
hold on

for ic=1:length(n)
    %From isotherm given in Equation 19 (multiply top and bottom  by Kc_{in}^{a/b}   with  n=a/b
    plot(ce,mm(ic)*K1b(ic)*ce.^n(ic)./(1+K1b(ic)*ce.^n(ic)),'-','LineWidth',LW,'Color', cmap(ic,:))
    if ic == 4 
        plot(ce,mm(ic)*K1b(ic)*ce.^n(ic)./(1+K1b(ic)*ce.^n(ic)),'--','LineWidth',LW, 'Color', cmap2(round(7/8*nc),:))
    end 
end 
scatter(ceHg,meHg,'marker','o', 'MarkerEdgeColor',[176/255 44/255 17/255],'LineWidth', 1);

grid on
xlim([0 max(ceHg)])
leg=legend('$a/b=1$','$a/b=2/3$', '$a/b=1/2$', '$a/b=0.595$');
set(leg, 'Interpreter', 'Latex','location','southeast') 
set(gca,'FontSize',FS,'LineWidth',1)
set(gca,'TickLabelInterpreter','latex')

subplot(122)
hold on
for ic=1:length(n)
    plot(1./ce(2:end),1/mm(ic)+(1./ce(2:end)).^n(ic)/(mm(ic)*K1b(ic)),'-','LineWidth',LW,'Color', cmap(ic,:))
    if ic== 4
        plot(1./ce(2:end),1/mm(ic)+(1./ce(2:end)).^n(ic)/(mm(ic)*K1b(ic)),'--','LineWidth',LW,'Color', cmap2(round(7/8*nc),:))
    end 
end 
scatter(1./ceHg,1./meHg,'marker','o', 'MarkerEdgeColor',[176/255 44/255 17/255],'LineWidth', 1);
grid on
xlim([0 2000])
leg=legend('$a/b=1$', '$a/b=2/3$', '$a/b=1/2$', '$a/b=0.595$');
set(leg, 'Interpreter', 'Latex','location','northwest') 
set(gca,'FontSize',FS,'LineWidth',1)
set(gca,'TickLabelInterpreter','latex')

% Two figure in two columns 
figw = 17.2; % cm
subfigw = 0.38; % Fraction of figw
subfigh = 0.75; % Fraction of figh
padleft = 1.5/figw; % Fraction of figw
padbottom = 3/figw; % Fraction of figw
padbetween = 1.3/figw; % Fraction of figw
figh = figw/(2.7);

for ip=1:2
    subplot(1,2,ip)
    box on
    set(gca,'FontSize',10,'FontName','Times New Roman')
    if ip == 1 
        xlab=xlabel('$c_e$ (mol/m$^3$)','Interpreter','latex','FontSize',FS);
        ylab=ylabel('$\bar{m}_e$ (mol/kg)','Interpreter','latex','FontSize',FS);
        xlab.FontSize=FS;
        ylab.FontSize=FS;
    elseif ip==2 
        xlab=xlabel('$1/c_e$ (m$^3$/mol)','Interpreter','latex','FontSize',FS);
        ylab=ylabel('$1/\bar{m}_e$ (kg/mol)','Interpreter','latex','FontSize',FS);
        xlab.FontSize=FS;
        ylab.FontSize=FS;
    end 
end

subplot(1,2,1)
set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
box on 
subplot(1,2,2)
set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom,subfigw,subfigh])
box on 

set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf','./Figures/Figure_5.pdf');

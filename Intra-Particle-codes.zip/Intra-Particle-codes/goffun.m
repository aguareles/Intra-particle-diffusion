function [SSE,Rsq] = goffun(cexp, tt12exp, c, tt12)
    % This function, written by  A. Valverde is used  to calculate the 
    % Goodness of Fit (GoF) parameters. It was written for use in
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161

    tt12exp=tt12exp(:);
    cexp=cexp(:);
    tt12=tt12(:);
    c=c(:);
    
    cteor=zeros(size(cexp,1),1);
    
    i=1;
    while i<=size(cexp,1)
        [~,idx] = min(abs(tt12exp(i)-tt12));
        if tt12(idx)<tt12exp(i)
            if idx<size(tt12,1)
                cteor(i)=interp1([tt12(idx),tt12(idx+1)],[c(idx),c(idx+1)],tt12exp(i));
            elseif idx==size(tt12,1)
                cteor(i)=c(idx);
            end
        elseif tt12(idx)>tt12exp(i)
            if idx>1
                cteor(i)=interp1([tt12(idx-1),tt12(idx)],[c(idx-1),c(idx)],tt12exp(i));
            elseif idx==1
                cteor(i)=c(idx);
            end
        elseif tt12(idx)==tt12exp(i)
            cteor(i)=c(idx);
        end      
        i=i+1;
    end
    
    res = cexp-cteor;
    SSE=sum(res.^2);
    SST=sum((cexp-mean(cexp)).^2); 
    Rsq = 1-SSE/SST;

end


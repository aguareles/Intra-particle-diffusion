function [fitresult, gof] = Figure_5_opt_ab(ceHg, meHg)
    % This function, written by  A. Valverde is used to fit the model to
    % the experimental data and is used to produce Figure 5
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [xData, yData] = prepareCurveData(ceHg, meHg);
    
    % Set up fittype and options where f = mmax*K^{1/b} and g = K^{1/b} 
    ft = fittype( 'f*x^n/(1+g*x^n)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.StartPoint = [0.567821640725221 0.0758542895630636 0.0539501186666071];
    
    % Fit model to data.
    [fitresult, gof] = fit( xData, yData, ft, opts );
end 



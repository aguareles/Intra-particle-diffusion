To generate Figures 3-9, simply run the MATLAB codes: 
Figure_3.m  --- this generates Figure 3 and stores the data generated. It is quite expensive
Figure_4.m  --- this generates Figure 4 and stores the data generated.
Figure_5_Table_3.m --- this generates Figure 5 and outputs the parameters contained within Table 3. Optimisation codes are called within this script
Figure_6_Table_4.m --- this generates Figure 6 and outputs the parameters contained within Table 4. Optimisation codes are called within this script
Figure_7.m --- this generates Figure 7. Optimisation codes are called within this script
Figure_8_driver_Table_7.m --- this generates Figure 8 and outputs the parameters contained within Table 7. Optimisation codes are called within this script
Figure_9_driver_Table_8.m --- this generates Figure 9 and outputs the parameters contained within Table 8. Optimisation codes are called within this script
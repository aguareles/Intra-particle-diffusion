function [fitresult, gof] = Figure_5_opt(ceHg, meHg, n)
    % This function, written by  A. Valverde is used to fit the model to
    % the experimental data and is used to produce Figure 5 
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [xData, yData] = prepareCurveData( ceHg, meHg);
    
    % Set up fittype and options, where f = mmax*K^{1/b} and g = K^{1/b} 

    if n==1
        ft = fittype( 'f*x^1/(1+g*x^1)', 'independent', 'x', 'dependent', 'y' );
    elseif n==1/2
        ft = fittype( 'f*x^(1/2)/(1+g*x^(1/2))', 'independent', 'x', 'dependent', 'y' );
    elseif n==1/3
        ft = fittype( 'f*x^(1/3)/(1+g*x^(1/3))', 'independent', 'x', 'dependent', 'y' );
    elseif n==2/3
        ft = fittype( 'f*x^(2/3)/(1+g*x^(2/3))', 'independent', 'x', 'dependent', 'y' );
    elseif n==1/4
        ft = fittype( 'f*x^(1/4)/(1+g*x^(1/4))', 'independent', 'x', 'dependent', 'y' );
    elseif n==1/5
        ft = fittype( 'f*x^(1/5)/(1+g*x^(1/5))', 'independent', 'x', 'dependent', 'y' );
    elseif n==2/5
        ft = fittype( 'f*x^(2/5)/(1+g*x^(2/5))', 'independent', 'x', 'dependent', 'y' );
    elseif n==3/4
        ft = fittype( 'f*x^(3/4)/(1+g*x^(3/4))', 'independent', 'x', 'dependent', 'y' );
    end
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Lower = [0 0];
    opts.StartPoint = [0.54972360829114 0.91719366382981];
    
    % Fit model to data.
    [fitresult, gof] = fit( xData, yData, ft, opts );

end 



function [fitresult, gof] = Figure_7_opt(qeinv, Tinv)
    % This function, written by  A. Valverde is used to fit the model to
    % the experimental data and is used to produce Figure 7 
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [xData, yData] = prepareCurveData( qeinv, Tinv );
    
    % Set up fittype and options.
    ft = fittype( 'F+G*log(x-invmm)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.StartPoint = [0.351659507062997 0.830828627896291 0.585264091152724];
    
    % Fit model to data.
    [fitresult, gof] = fit( xData, yData, ft, opts );
end 




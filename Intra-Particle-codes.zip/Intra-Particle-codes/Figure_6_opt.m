function [fitresult] = Figure_6_opt(cciexp, tminust12exp, b, mu)
    % This function, written by  A. Valverde is used to fit the model to
    % the experimental data and is used to produce Figures 8 and 9 
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [xData, yData] = prepareCurveData( cciexp, tminust12exp );
    
    % Set up fittype and checks that we are fitting with the right values (in
    % this structure, cannot input mu: must input the number explicitly). 
    if b==2
        if (mu >=1.91253200134909) && (mu<=1.9125320013491)
            ft = fittype( '(Tau/beta)*( ((1+beta/(1.912532001349091^2))*log(x)-((beta+(1.912532001349091-1)^2)/(-1+1.912532001349091^2))*log(1-x)+((beta+(1.912532001349091^2)*(1.912532001349091-1)^2)/((-1+1.912532001349091^2)*1.912532001349091^2))*log((1.912532001349091^2)-x)) - ((1+beta/(1.912532001349091^2))*log(0.5)-((beta+(1.912532001349091-1)^2)/(-1+1.912532001349091^2))*log(0.5)+((beta+(1.912532001349091^2)*(1.912532001349091-1)^2)/((-1+1.912532001349091^2)*1.912532001349091^2))*log((1.912532001349091^2)-0.5)) );', 'independent', 'x', 'dependent', 'y' );
        else 
            warning('!!!You must manually change the mu value entered in Figure_6_opt (line 10)!!!')
        end 
    else
        warning('!!!Figure_6_opt only coded for a=1 and b=2!!!')
    end
    
    excludedPoints = (xData <= 0) | (xData >= 1);
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Lower = [0 0];
    opts.StartPoint = [0.073994769576938 100];
    opts.Exclude = excludedPoints;
    
    % Fit model to data.
    [fitresult, ~] = fit( xData, yData, ft, opts );
end 



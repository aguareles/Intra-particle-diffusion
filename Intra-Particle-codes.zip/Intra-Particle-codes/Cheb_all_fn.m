function [t_pde,t_ana,c_pde,C_ana, z_pde, Cconc_TW_F, etatilde_TW_F, t12] = Cheb_all_fn(input,what)
    % This function, written by L. C. Auton, provides the numerical solution to the
    % system of coupled PDEs, the full numerical travelling wave solution and calls 
    % the analytical travelling wave solutions for 
    % 'An analytical investigation into solute transport and sorption via
    % intra-particle diffusion in the dual-porosity limit', 2024
    % https://doi.org/10.48550/arXiv.2311.10161. 
    % Functions used to calculate t_1/2 were written by M. Calvo-Schwarzwalder
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Unpack parameters (global within this 'parent function').
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % what has 2 options 'all' or 'pde'. 
    % Note that t12 is calculated from the full numerical solution.
    % When mathcing to experimental data it is estimated from the data. 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    N = input.N; %This is the number of data points for the full numerical simulation. 
                 % Note that, N must increase with l for stability at early times and
                 % increase with decreasing 1/Pe. 
    a = input.a;
    b = input.b;
    Da = input.Da;
    invPe = input.invPe;
    beta = input.beta;
    mu = input.mu;
    alpha = input.alpha;
    l=input.l;
    tmesh = input.tmesh; 
    Tau = input.Tau;

    if ~isfield(input, 'big')
        input.big = 80; % default value but this may nned to change for different input parameters 
        disp('!! Using fixed big = 80 !!')
    end 
    big = input.big; 
    
    if what == 'all'
        [z_pde,t_pde,c_pde,t12,~] = ChebPDE; %solves full PDE
       % [t_ana,C_ana] = ScaleUpApproximate(t12,  c_num2, a,b,beta,mu); %Gives analytical solutions 
        [t_ana_minus_t12, C_ana] = Analytical_calculator(tmesh-t12, a, b, mu, Tau, beta);                                                              % for a=1, b=1, 2, 3
        t_ana = t_ana_minus_t12+t12;
        [etatilde_TW_F,Cconc_TW_F] = Cheb_ODE_TW_Full(t12); % Solves the `full' travelling wave 
                                                            % system of 3 coupled ODEs
    elseif what == 'pde'
        [z_pde,t_pde,c_pde,t12,~] = ChebPDE;
        t_ana = NaN; 
        C_ana= NaN; 
        etatilde_TW_F = NaN;
        Cconc_TW_F = NaN;
    end 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % This function solves the full system of coupled PDEs. 
    % Numerical Scheme written by L. C. Auton
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [z_pde,t_pde,c_pde, t12, c_num2] = ChebPDE
        % Build Chebyshev differentiation matrices and initialise system   
        [X,D] = chebdif(N,2);
        
        Z = -l/2*X+l/2; % rescale domain [1,-1] |--> [0,l]
        dXdZ = -2/l; % coordinate transformation 
        
        %Define useful vectors of zeros 
        z1 = zeros(N,2*N);
        z2 = zeros(2*N,3*N);
        
        %Construct differentiation matrices for spatial derivatives in c.
        D1 = [dXdZ*D(:,:,1) z1; z2]; % First order derivative.
        D2 = [(dXdZ^2)*D(:,:,2) z1; z2]; % Second order derivative.
        
        % Define the identity matrix of size 3N
        I = eye(3*N);
        %define indices:  y is the concatinated vector [c, c_p, m_p]^T
        i = 2 : N-1;            %For internal nodes of C (ie without BCs)
        i_bc = 1:N;             %for all of c (ie c= y(i_bc))
        j = N+1 : 2*N;          %for all of c_p (ie c_p= y(j))
        j_inner = N+2 : 2*N-1;  % For internal nodes of c_p (ie without BC)
        k = 2*N+1 : 3*N;        %for all of m_p (ie m_p= y(k))

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Construct residual and Jacobian for m_p ODE
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        function [dm_pdt, dm_pdy] = fun_m_p(y)
        
            dm_pdt = y(j).^a.*(mu-y(k)).^b - (mu-1)^b*y(k).^b;
            dm_pdy = diag(a*y(j).^(a-1).*(mu-y(k)).^b)*I(j,:) ...
                    - diag(b*y(j).^a.*(mu-y(k)).^(b-1)+...
                    b*(mu-1)^b*y(k).^(b-1))*I(k,:);
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Analytically build  residual 
        function [dydt] = fun_dydt(t,y)
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate residual (analytical)
            Left = y(1) - invPe*D1(1,:)*y -1; % Inlet condition
            Right = D1(N,:)*y;                % Outlet condition
            [dm_pdt, ~] = fun_m_p(y);         % Call function for m_p
        
            dydt = [Left;
                   invPe*D2(i,:)*y-D1(i,:)*y- beta*(y(i)-y(j_inner)) ;...
                   Right; ...
                   beta*(y(i_bc)-y(j))-dm_pdt;...
                   dm_pdt];
            
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Analytically build Jacobioan
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        function [Jac] = fun_dJac(~,y)
        
            [~, dm_pdy] = fun_m_p(y);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate Jacobian (analytical)
            Left = I(1,:) - invPe*D1(1,:);
            Right = D1(N,:);
            
            Jac =  [Left;
                   invPe*D2(i,:)-D1(i,:)- beta*(I(i,:)-I(j_inner,:)) ;...
                   Right; ...
                   beta*(I(i_bc,:)-I(j,:))-dm_pdy;...
                   dm_pdy];
        
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Analytically construct mass matrix
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        M = [zeros(1,3*N);Da*I(i,:);zeros(1,3*N);alpha*I(j,:);I(k,:)];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Define ODE solver options 
        op = odeset('jacobian',@fun_dJac,'mass',M,'abstol',1e-5,'reltol',1e-4, ...
            'MassSingular', 'yes', 'MStateDependence','none');
        y0 = zeros(3*N,1); %Intialise system (ICs)
        
        [t,y] = ode15s(@fun_dydt,tmesh,y0,op); %Solve PDE system.
      
        %Extract output quantites and calculate t_1/2 (t12) used for the 
        % travelling wave solutions
        t_pde = t;
        c_pde = y;
        z_pde = Z;
        c = c_pde(:,N);
        t = t_pde;
        [t12,c_num2] = find_t12(t,c); 
    end 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % This function solves coupled system of 3 TW first order ODEs without
    % simplifications with Sdot determined analytically. Numerical Scheme
    % written by L. C. Auton
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [etatilde,Y] = Cheb_ODE_TW_Full(t12)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Set number of grid points
        NF = 501; % Must be odd (to enforce the value C(0)=1/2 more easily). 
    
        % Define parameters 
        Sdot = 1/(1+Da+alpha); 
        A = (1+alpha)*Sdot;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Define control parameters
        minchange = 1e-9;
        tol = 1e-7;
        maxresid = 1e10;
        maxnoit = 5e3;
        
        %Initial solution guess
        C0 = [1; ones((NF-1)/2-1,1); 1/2; zeros((NF-1)/2,1)]; 
        Y0 = [C0; C0; C0]; 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Build Chebyshev differentiation matrices 
        [XF,DF] = chebdif(NF,1);
        
        eta = -(big-(-big))/2*XF; % rescale domain [1,-1] |--> [-big,big]
        Ceta_0_ind = (NF+1)/2; %define index which corresponds to eta=0. 
        dXdeta = -1/(big); % coordinate transformation 
        
        %Define useful vectors of zeros 
        z1C = zeros(NF,2*NF);
        z2C = zeros(2*NF,3*NF);
        z1Cp = zeros(NF,3*NF);
        z2Cp = zeros(NF,NF);

        %Construct differentiation matrices for eta derivatives.
        E1C = [dXdeta*DF(:,:,1) z1C; z2C];                 % For C 
        E1Cp = [z1Cp; z2Cp dXdeta*DF(:,:,1) z2Cp; z1Cp];   % For C_p 
        E1Mp = [z1Cp; z1Cp;  z2Cp z2Cp dXdeta*DF(:,:,1)];  % For M_p 

        % Define the identity matrix of size 3N
        I = eye(3*NF);
        
        %Define indices:  Y is the concatinated vector [C, C_p, M_p]^T
        i = 1 : NF; %for all of C (ie C= y(i))
        i1 = 1:(NF-1)/2; % for C to the left of C_1/2
        i2 = (1+(NF+1)/2):NF; % for C to the right of C_1/2
        j = NF+1 : 2*NF;  %for all of C_p (ie C_p= y(j)) 
        k = 2*NF+1 : 3*NF;  %for all of M_p (ie M_p= y(k))
        k_inner = 2*NF+1 : 3*NF-1; %For M_p exclusing the outlet (where a constraint is applied) 
        
        %Intialise the system 
        res = 1;
        change = 1;
        noit = 0;
        stop = false;     
        Y = Y0; 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Start iteration loop
        while ~stop
            if  change<minchange && res < tol % Newton iterations/Criterion for convergence
                stop = true;
            end
            noit = noit + 1;
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate residual: 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
            %Call residual and Jacobian for M_p 
            [dM_pdeta, dM_pdY] = fun_M_p_full(Y);

            %Calculate residual for C equation
            dCdeta1 = invPe*E1C(i,:)*Y - (A*Y(i))+ Sdot*(alpha*Y(j)+Y(k));
            dCdeta = [dCdeta1(i1); Y(Ceta_0_ind)-1/2; dCdeta1(i2)];
            
            % Define residual
            dYdeta = [ dCdeta;  ...
                Sdot*alpha*E1Cp(j,:)*Y+beta*(Y(i)-Y(j))-dM_pdeta;...
                Sdot*E1Mp(k_inner,:)*Y+ dM_pdeta(1:end-1); 
                Y(end)];
            
            %Calculate Jacobian for C equation
            dCdY1 = invPe*E1C(i,:) - A*I(i,:) + Sdot*(alpha*I(j,:)+I(k,:)); 
            dCdY = [dCdY1(i1,:); I(Ceta_0_ind,:); dCdY1(i2,:)];
            
            %Compile the Jacobian for y
            Jac_TW = [ dCdY ; ...
                 Sdot*alpha*E1Cp(j,:)+beta*(I(i,:)-I(j,:))-dM_pdY;...
                 Sdot*E1Mp(k_inner,:)+ dM_pdY(1:end-1,:); 
                 I(end,:)];

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Update solution and calculate residual
            YNew = max(0,Y-Jac_TW\dYdeta);
            res = norm(dYdeta,inf)/NF+norm(imag(YNew),inf);
            change = norm(YNew-Y,inf)+norm(imag(YNew),inf);
            Y = YNew;    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Kill the code if the residual is too big or the number of iterations is too many (ie, if code has failed)        
            if res > maxresid
                error(['residual greater than ' num2str(maxresid)])
            end
            if noit > maxnoit
                error(['number of iterations greater than ' num2str(maxnoit)])
            end

            disp(['ODE_System_full_TW ' num2str(noit) ': res = ' num2str(res) ' and change = ' num2str(change)])
        
        % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % % Calculate output quanitites 
        end 
        etatilde = t12-eta; 
        function [dM_pdeta, dM_pdY] = fun_M_p_full(Y)
            dM_pdeta = (Y(j).^a.*(mu-Y(k)).^b - (mu-1)^b*Y(k).^b);
            dM_pdY = (diag(a*Y(j).^(a-1).*(mu-Y(k)).^b)*I(j,:) -...
                    diag(b*Y(j).^a.*(mu-Y(k)).^(b-1)+b*(mu-1)^b*Y(k).^(b-1))*I(k,:));
        end
    end 
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %Below: Functions used to calculate t_1/2 (t12). Written by M. Calvo-Schwarzwalder
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   function [t12,c_num2] = find_t12(t_num,c_num)
        Nt = length(c_num);
        c_num2 = [];
        t_num2 = [];
        for i = 1:Nt
            if IsContained(c_num(i),0,1,'open')
                c_num2 = [c_num2; c_num(i)];
                t_num2 = [t_num2; t_num(i)];   
            end
        end
        t12 = halftime(t_num2,c_num2);
    end

    function z = halftime(x,y)
        Nf = length(x);
        i_pre = 1;
        i_post = Nf;
        for i=1:Nf-1
            if y(i)==.5
                i_pre = i;
                i_post = i;
                break
            elseif y(i)<.5 && y(i+1)>.5
                i_pre = i;
                i_post = i+1;
                break
            end
        end
        z = interp1(y(i_pre:i_post),x(i_pre:i_post),0.5);
    end

    function answer = IsContained(x,l1,l2,type)
        if strcmp(type,'open') && x>l1 && x<l2
            answer = true;
        elseif strcmp(type,'closed') && x>=l1 && x<=l2
            answer = true;
        else
            answer = false;
        end
    end
end
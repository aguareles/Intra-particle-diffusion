close all; clear all; clc;
% This code, written by L. C. Auton, produces Figure 4 of 
% 'An analytical investigation into solute transport and sorption via
% intra-particle diffusion in the dual-porosity limit', 2024
% https://doi.org/10.48550/arXiv.2311.10161
% The functions TrackFront and order contained within were written by  M.Calvo-Schwarzwalder
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Input representative parameters
input.a = 1; 
input.l = 35; % Rows 1 and 3: experimental data puts l \in (7.4,44)
input.mu = 1.1;
input.invPe = 0.1; %1/Pe
input.N = round(100/input.invPe);
input.beta = 5; 
input.Da = 1e-5;
input.alpha = input.Da/2; 
input.big = 80;
input.Tau = 1; % This is used to scale the solution to match with experimental data. 
% As we are producing a dimensionless solution here, we set it trivially to 1.

bs = [1 2 3]; 

%Unpack physical parameters
invPe = input.invPe;
Da = input.Da; 
mu = input.mu;
beta = input.beta; 
N = input.N;

%Construct vector of times at which to plot

tmax1 = 50; %Max time for row 1 
tmax2 = 1000; %Max time for row 2 
tmax3 = 200; %Max time for row 3

Long_plot_late1 = 8;  
Long_plot_early1 =10;
Long_plot_late2 = 1000;
Long_plot_early2 =50;
div = 1;

timeearly1 = logspace(log10(Da*invPe),log10(div), Long_plot_early1);
timelate1 = linspace(div,tmax1,Long_plot_late1); 
timeearly2 = logspace(log10(Da*invPe),log10(div), Long_plot_early2);
timelate2 = linspace(div,tmax2,Long_plot_late2); 

%Input vectors of times
input.tmesh1 = [timeearly1  timelate1(2:end)];
input.tmesh2 = [timeearly2  timelate2(2:end)];
input.tmesh3 = linspace(0,tmax3,input.N);

%Preallocate vectors for speed

C_num1 = zeros(length(input.tmesh1),input.N,length(bs));
z_pde1 = zeros(input.N, length(bs));

Front = cell(length(bs),1);
C_num2 = zeros(length(input.tmesh2),input.N,length(bs));
z_pde2 = zeros(input.N, length(bs));
t_pde2 = zeros(length(input.tmesh2),length(bs));

C_num3 = zeros(length(input.tmesh3),input.N,length(bs));
t_pde3 = zeros(length(input.tmesh3),length(bs)); 

%Parameters for plotting
profiletitles = {'$a=1, b=1$','$a=1,b=2$','$a=1,b=3$'}; 

nc = length(input.tmesh1)+2; 
cmaps = parula(nc);
cmaps2 = pink(length(bs)+3);
Coral = [238/255, 134/255, 91/255]; 
DarkViolet = [135/255 25/255 202/255];
DarkGrey = [168/255, 168/255, 168/255];
N_font = 10;
LWlines = 1.2;
LWborder = 1;
LWborder2 = .85;
LW3lines = 1.5;

figure(4)
% Three figures in three columns with inset in bottom row. 
figw = 17.2; % cm
subfigw = 0.25; % Fraction of figw
subfigh = 0.23; %.24 % Fraction of figh
padleft = 1.35/figw; % Fraction of figw
padbottom = 2/figw; %1.25/figw; % Fraction of figw
padbetween = 1/figw; % Fraction of figw
figh = 1.1*figw; %1.1*figw; 

for icol = 1:length(bs)
    b = bs(icol);

    %Unpack parameters
    input.b = b; 
    Bb = mu^b*beta/(beta+mu^b);  %Construct a useful parameter grouping for early time solutions

    %----------------------------------------------------------------------
    %Plots 1st row: 
    %----------------------------------------------------------------------

    subplot(3,3,icol)
    box on
    %this load/calculates and saves and subsequently plots: 
    %----------------------------------------------------------------------
    input.tmesh = input.tmesh1; 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Generate and save/load data:
    what  = 'pde';
    filename1 = ['Results/Front_tracking_Row_1 b= ' num2str(input.b) ' a =' num2str(input.a) ...
        ' Da =' num2str(input.Da) ' invPe=' num2str(input.invPe) ' mu=' num2str(input.mu)...
        ' N =' num2str(input.N) ' tmax=' num2str(tmax1) ' l=' num2str(input.l)... 
        ' beta =' num2str(input.beta) ' alpha =' num2str(input.alpha) ' length(tmesh) =' num2str(length(input.tmesh)) '.mat'];
    %If data exists --- load it 
    if exist(filename1,'file')==2 
        load(filename1)
    else 
        %[~,~,~,C_pde,~,~,z_pde] = Cheb_all_fn(input,what); 
        [~,~,C_pde,~, z_pde, ~, ~, ~] = Cheb_all_fn(input,what);
        C_num1(:,:,icol) = C_pde(:,1:N);
        z_pde1(:,icol)= z_pde;
        save(filename1,'z_pde1','C_num1')
    end 
    hold on;
    for i=1:length(input.tmesh)
        plot(z_pde1(:,icol),C_num1(i,:,icol), 'Color', cmaps(i,:), 'LineWidth', LWlines);
        drawnow
    end
    plot(z_pde1(:,icol), exp(-Bb*z_pde1(:,icol)),'r--','LineWidth', LWlines);
    %----------------------------------------------------------------------
    %Pretty format/ labels (normally at bottom -- moved because insets
    xlim([0 35])
    ylim([0 1])
    if icol == 1
        ylabel('$C(\zeta,\tau)$','Interpreter','latex')
    end 
    xlabel('$\zeta$','Interpreter','latex')
    title(profiletitles{icol},'Interpreter','latex')
    set(gca,'Layer','bottom')
    set(gca,'FontSize',N_font,'FontName','Times New Roman','LineWidth', LWborder)
    
    %----------------------------------------------------------------------
    %Plots 3rd row: 
    %----------------------------------------------------------------------
    subplot(3,3,7+(icol-1))
    %----------------------------------------------------------------------
    % Set up inset structure 
    h_main = gca; 
    set(h_main,'FontSize',N_font,'FontName','Times New Roman','LineWidth', LWborder)
    %Set up for inset (postitoning and font size)
    if icol == 3
        h_inset = axes('Position',[0.247+(icol-1)*0.328 0.147 0.071 0.17]); 
    else 
        h_inset = axes('Position',[0.247+(icol-1)*0.33 0.147 0.071 0.17]); 
    end 
    % first number increasing it moves it to the right 
    % second increasing it moves it up 
    % third number controls insert width 
    % fourth controls insert height
    set(h_inset,'FontSize',N_font-2,'FontName','Times New Roman','LineWidth', LWborder)
    %----------------------------------------------------------------------
    %Plot main figure
    axes(h_main)
    %this calculates and subsequently plots: 
    %----------------------------------------------------------------------
    input.tmesh = input.tmesh3;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Generate and save/load data:
       what  = 'all';
    filename3 = ['Results/Front_tracking_Row_3 b= ' num2str(input.b) ' a =' num2str(input.a) ...
        ' Da =' num2str(input.Da) ' invPe=' num2str(input.invPe) ' mu=' num2str(input.mu)...
        ' N =' num2str(input.N) ' tmax=' num2str(tmax3) ' l=' num2str(input.l)... 
        ' beta =' num2str(input.beta) ' alpha =' num2str(input.alpha) ' what =' num2str(what) '.mat'];
    %If data exists --- load it 
    if exist(filename3,'file')==2 
        load(filename3)
    else 
        %[t_pde,t_ana,etatilde,C_pde,C_ana, C_TW,~,Cconc_TW_F, etatilde_TW_F] = Cheb_all_fn(input,what); 
        [t_pde,t_ana,C_pde,C_ana, z_pde, Cconc_TW_F, etatilde_TW_F, t12] = Cheb_all_fn(input,what);
        C_num3(:,:,icol) = C_pde(:,1:N);
        t_pde3 = t_pde;
        t_ana3 = t_ana;
        etatildeF3 = etatilde_TW_F;
        C_TWF3 = Cconc_TW_F(1:length(etatilde_TW_F)); 
        C_ana3 = C_ana;
        %C_TWSN3 = C_TW; 
        %etatildeSN3 = etatilde;
        save(filename3,'C_num3','t_pde3','t_ana3','etatildeF3','C_TWF3','C_ana3')
    end 
    hold on
    plot(t_pde3(:,1),C_num3(:,end,icol),'-','Color','k', 'LineWidth', LW3lines);
    drawnow
    plot(etatildeF3,C_TWF3,'-.','Color',Coral, 'LineWidth', LW3lines);
    plot(t_ana3,C_ana3,'--','Color',DarkViolet, 'LineWidth', LW3lines);
    drawnow

    %----------------------------------------------------------------------
    % Main axis labels
    axes(h_main)
    box on
    set(gca,'FontSize',N_font,'FontName','Times New Roman','LineWidth', LWborder)
    %set position of main 
    set(gca,'Position',[padleft+(icol-1)*(subfigw+1.36*padbetween),padbottom,subfigw,subfigh])
    if icol == 1
        ylabel('$C(l,\tau)$','Interpreter','latex')
    end 
    ylim([0 1])
    xlim([0 100])
    if icol==3 
         legend({'Full PDE system','Full numerical travelling wave',...
                'Approximate analytical travelling wave'},...
                'Location',[0.182 0.01 .7 .05],'Orientation','horizontal',...
                'Interpreter','latex','FontSize',N_font-2)
    end 
    xlabel('$\tau$','Interpreter','latex') 
    set(h_main,'xscale','lin')
    set(h_main,'yscale','lin')
    set(h_main,'XMinorTick','on')
    set(h_main,'Layer','bottom')
    %----------------------------------------------------------------------
    % Inset plot and labels
    axes(h_inset)
    hold all; hold on;
    %this plots inset: 
    %----------------------------------------------------------------------
    plot(t_pde3(:,1),C_num3(:,end,icol),'-','Color','k', 'LineWidth', LW3lines);
    plot(etatildeF3,C_TWF3,'-.','Color',Coral, 'LineWidth', LW3lines);
    plot(t_ana3,C_ana3,'--','Color',DarkViolet, 'LineWidth', LW3lines);
    % inset label etc: 
    %----------------------------------------------------------------------
    box on 
    set(h_inset,'xscale','lin')
    set(h_inset,'yscale','lin')
    if icol == 2
        set(h_inset,'XMinorTick','on')
    elseif icol == 3
        xlim(h_inset,[41.8, 48.2])
        set(h_inset,'XMinorTick','on')
        set(h_inset,'XTick',[ 42 45  48] )
        set(h_inset,'XTickLabel',{'42','45','48'})
        xtickangle(0)
    end
    ylim([0.89  0.91])
    set(h_inset,'Layer','top')
    disp(['progress: ' num2str(100*icol*2/length(bs)/3) '%']);
end 

%Set filter length and desired times for row 2
input.l =500;
input.tmesh = input.tmesh2;
%Generates data and saves/loads saved data
for icol = 1:length(bs)
    b = bs(icol); 
    input.b = b; 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Generate and save/load data:
    filename2 = ['Results/Front_tracking_Row_2 b= ' num2str(input.b) ' a =' num2str(input.a) ...
                 ' Da =' num2str(input.Da) ' invPe=' num2str(input.invPe) ' mu=' num2str(input.mu)...
                 ' N =' num2str(input.N) ' tmax=' num2str(tmax2) ' l=' num2str(input.l)... 
                 ' beta =' num2str(input.beta) ' alpha =' num2str(input.alpha) ' length(tmesh) =' num2str(length(input.tmesh)) '.mat'];
    %If data exists --- load it 
    if exist(filename2,'file')==2 
        load(filename2)
    else 
        %[t_pde,~,~,C_pde,~, ~, z_pde] = Cheb_all_fn(input,'pde');
        [t_pde,~,C_pde,~, z_pde, ~, ~, ~] = Cheb_all_fn(input,'pde');
        C_num2(:,:,icol) = C_pde(:,1:N);
        z_pde2(:,icol) = z_pde; 
        t_pde2(:,icol)= t_pde; 
        save(filename2,'z_pde2','C_num2','t_pde2')
    end 
    disp(['progress: ' num2str(100*icol/length(bs)/3+(200/3)) '%']);

    [tf1,xf1] = TrackFront(z_pde2(:,icol),t_pde2(:,icol),C_num2(:,:,icol),.1);
    [tf2,xf2] = TrackFront(z_pde2(:,icol),t_pde2(:,icol),C_num2(:,:,icol),.5);
    [tf3,xf3] = TrackFront(z_pde2(:,icol),t_pde2(:,icol),C_num2(:,:,icol),.9);

    Front{icol}.xf1 = xf1;
    Front{icol}.tf1 = tf1;
    Front{icol}.xf2 = xf2;
    Front{icol}.tf2 = tf2;
    Front{icol}.xf3 = xf3;
    Front{icol}.tf3 = tf3;
end

figure(4)
for i = 1:length(bs)
    subplot(length(bs), 3, 3+i);
    tfront1 = Front{i}.tf1;
    xfront1 = Front{i}.xf1;
    tfront2 = Front{i}.tf2;
    xfront2 = Front{i}.xf2;
    tfront3 = Front{i}.tf3;
    xfront3 = Front{i}.xf3;

    %----------------------------------------------------------------------
    %Plots 2nd row: 
    %----------------------------------------------------------------------
    hold on;
    loglog(tfront1,xfront1,'-','LineWidth', LWlines ,'Color',cmaps2(1,:))
    loglog(tfront2,xfront2,'-','LineWidth', LWlines ,'Color',cmaps2(2,:))
    loglog(tfront3,xfront3,'-','LineWidth', LWlines ,'Color', cmaps2(3,:))
    loglog(logspace(-5,order(Long_plot_late2),100),logspace(-5,order(Long_plot_late2),100),'--','LineWidth', LWlines,'Color',DarkGrey)
    if i==1 
        legend({'$C = 0.1$','$C  = 0.5$','$C = 0.9$'},'Location','northwest','Interpreter','latex')
    end 
    %----------------------------------------------------------------------
    %Pretty format/ labels (normally at bottom -- moved because insets
    box on
    set(gca,'Layer','bottom')
    set(gca,'FontSize',N_font,'FontName','Times New Roman','LineWidth', LWborder2)
    if i==1
        ylabel('$\zeta^\star$','Interpreter','latex')
    end  
    set(gca,'FontSize',10,'FontName','Times New Roman')
    xlabel('$\tau$','Interpreter','latex')
    ylim([1e-2 5e2])
    xlim([1e-5, 1e3])
    xtickangle(0)
    set(gca,'xscale','log')
    set(gca,'yscale','log')
    set(gca,'XTick',[1e-5 1e-4  1e-3 1e-2 1e-1 1e0 1e1 1e2 1e3 ] )
    set(gca,'XTickLabel',{'','10^{-4}','','10^{-2}','','10^{0}','','10^{2}',''})
end

%Positions the top two rows of the figure 
subplot(3,3,1)
set(gca,'Position',[padleft,padbottom+2*(subfigh+1.35*padbetween),subfigw,subfigh])
subplot(3,3,2)
set(gca,'Position',[padleft+(subfigw+1.36*padbetween),padbottom+2*(subfigh+1.35*padbetween),subfigw,subfigh])
subplot(3,3,3)
set(gca,'Position',[padleft+2*(subfigw+1.36*padbetween),padbottom+2*(subfigh+1.35*padbetween),subfigw,subfigh])

subplot(3,3,4)
set(gca,'Position',[padleft,padbottom+(subfigh+1.35*padbetween),subfigw,subfigh])
subplot(3,3,5)
set(gca,'Position',[padleft+(subfigw+1.36*padbetween),padbottom+(subfigh+1.35*padbetween),subfigw,subfigh])
subplot(3,3,6)
set(gca,'Position',[padleft+2*(subfigw+1.36*padbetween),padbottom+(subfigh+1.35*padbetween),subfigw,subfigh])

set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf','Figures/Figure_4.pdf');



%% Functions


function [tf,xf] = TrackFront(z,t,C,a)

Nt = max(size(t));
Nz = max(size(z));

xf = [];
tf = [];

for i=1:Nt

    if max(C(i,:)) >= a

        [~,j] = min(abs(C(i,:) - a));

        if j>1 && j<Nz

            if C(i,j) == a
                xfi = z(j);
            elseif C(i,j) > a
                if C(i,j)==C(i,j+1)
                    xfi = (z(j)+z(j+1))/2;
                else
                    xfi = interp1(C(i,j:j+1),z(j:j+1),a);
                end
            else
                if C(i,j)==C(i,j-1)
                    xfi = (z(j)+z(j-1))/2;
                else
                    xfi = interp1(C(i,j-1:j),z(j-1:j),a);
                end
            end
            xf = [xf; xfi];
            tf = [tf; t(i)];
        end

    end
end

end

function n = order(x)
n = floor(log10(x));
end